# Fieldwork Operations Co-Pilot User Guide

This guide explains how to start the backend and web app locally, what each page does, and how to solve common problems. For the Chinese version, see [USER_GUIDE_ZH.md](USER_GUIDE_ZH.md).

> The web app and AI use the **course-provided data** in `data/` (120 orders), with the business date fixed at 2026-04-01. All services listen on `127.0.0.1` only and have no login, so do not expose them to a LAN or the internet.

## 1. Prerequisites

| Software | Version | Check with |
|---|---|---|
| Python | 3.11 or later | `py -3.11 --version` (Windows) / `python3 --version` (macOS) |
| Node.js | 20 or later | `node --version` |

The first start needs an internet connection to install dependencies. Run all commands below from the **project root**, the folder that contains `backend/` and `frontend/`.

## 2. Starting the backend and web app

You need **two terminal windows** running at the same time: one for the backend (port 8000) and one for the web app (port 5173). Keep both open.

### Windows (PowerShell)

**Window 1: backend**

```powershell
cd <project folder>
# First time only: create the virtual environment and install dependencies
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r backend\requirements.txt

# Every time
.\.venv\Scripts\python.exe -m uvicorn backend.dev:app --host 127.0.0.1 --port 8000 --reload --reload-dir backend
```

**Window 2: web app**

```powershell
cd <project folder>\frontend
# First time only: install dependencies
npm ci

# Every time
npm run dev
```

### macOS (Terminal)

**Window 1: backend**

```bash
cd <project folder>
# First time only
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r backend/requirements.txt

# Every time (run `source .venv/bin/activate` first in a new window)
python -m uvicorn backend.dev:app --host 127.0.0.1 --port 8000 --reload --reload-dir backend
```

**Window 2: web app**

```bash
cd <project folder>/frontend
npm ci        # first time only
npm run dev
```

### Opening the app

| Address | Purpose |
|---|---|
| <http://127.0.0.1:5173> | Main web app |
| <http://127.0.0.1:8000/health> | Backend health check |
| <http://127.0.0.1:8000/docs> | Backend API docs (you can try requests from this page) |

When the top-right corner shows **API connected**, the web app and backend are talking to each other. To stop the services, press `Ctrl+C` in both terminals.

> **About `--reload`:** with this flag, the backend restarts automatically when code under `backend/` changes. Use it during development. Without it, you must restart the backend by hand after every change, or the web app keeps calling the old code (a typical symptom is `Not Found` from a new endpoint).

## 3. Features

The left sidebar has six pages, and there is also a full-screen chat page.

### 3.1 Overview

- **Ask operations box:** type a question and press Enter, or click one of the example questions, to open the AI chat. AI must be set up first; see 3.7.
- **Generate morning brief:** runs the deterministic rules and lists the highest-priority operational findings.
- **Stage throughput:** this week's output and daily average for each production stage (KNITTING / ASSEMBLY / WASHING / PACKING).
- **Order pulse:** the latest order records. Click *Open order book* to go to the Orders page.

### 3.2 Orders

- Filter by **Order ID, Customer, Status and Stage**, then click *Search*. All filters must match together.
- Shows the number of matching orders and their total pieces, with pagination.

### 3.3 Production

- Choose a **Start date** and **End date** (both included) and an optional **Stage**, then click *Run report*.
- Shows factory-wide daily output per stage. Each stage is a **separate process count**; do not add stages together to get finished pieces.
- Missing records are never treated as zero. Sundays are non-operating days.

### 3.4 Feasibility

- Enter the **Product, Category (TOPS / ACCESSORIES), Quantity and Requested due date**, and optionally turn on *Evaluate outsourcing*.
- Click *Estimate feasibility* to estimate a likely production window from recent output and the current order load.
- The result is an **estimate**, not a schedule or a delivery promise.

### 3.5 Action log

- Lists the actions recorded in the local SQLite database: prepared, confirmed and cancelled.
- Actions are only recorded locally. They **never** send messages, create reminders or start watches.

### 3.6 Claim evidence

Every claim badge (`CLM-...`) on the pages and in chat is clickable. It opens the **Claim trace** panel on the right, where you can:

- See the source data and the calculation behind the finding.
- Click *Re-verify claim* to recalculate from current data. The result is `CONSISTENT`, `DRIFTED` (the data has changed) or `SOURCE_UNAVAILABLE`.

### 3.7 AI settings

**AI connection: setting up the model**

1. **AI provider:** choose ChatGPT (OpenAI), Claude (Anthropic), Gemini (Google) or DeepSeek. The backend sets each provider's API address, so you don't enter a URL.
2. **Model:** choose one of the provider's preset models. Changing the provider selects its first model automatically.
3. **API key:** paste an API key from that provider's developer platform.
4. Click **Save settings**, then **Test connection**.

| Provider | Preset models | Get an API key at |
|---|---|---|
| ChatGPT | GPT-4.1 mini (default), GPT-4.1, GPT-6 Luna | platform.openai.com |
| Claude | Claude Sonnet 5.5, Claude Opus 5.5, Claude Haiku 4.5 | console.anthropic.com |
| Gemini | Gemini 3.8 Flash, Gemini 3.5 Flash-Lite, Gemini 3.1 Pro (Preview) | aistudio.google.com |
| DeepSeek | DeepSeek V4.1 Flash, DeepSeek V4 Pro | platform.deepseek.com |

API key safety:
- After you save, the backend **encrypts** the key and stores it in the local SQLite database. The page never shows it again; it only shows *CONFIGURED*.
- To replace the key, enter a new one and save. To change only the provider or model, leave the key box empty and the saved key is kept.
- Click *Remove key* to delete the saved key.
- Testing the connection and chatting call the provider's API and **may cost money**.

**Chat memory (optional, off by default)**

- When it is on, you can add preferences by hand (for example "keep answers short"), and later chats use them as context.
- Memories are preferences only, **never** a source of business facts. Orders, output and other facts are always looked up live by the tools.
- Delete memories one at a time, or click *Clear all memories*.

### 3.8 AI chat (/chat)

- Open it from the Overview question box, or go to <http://127.0.0.1:5173/chat>.
- The AI can call only the **read-only** tools below. The backend calculates every number; the AI never does its own calculations.

| Tool | Example question |
|---|---|
| Order search | "Which TrendCart orders are in progress?" |
| Production output | "How did assembly perform last week?" |
| Order risk | "Is ORD-058 at risk of missing its due date?" |
| Output normality | "Was knitting output normal on April 1?" |
| New order feasibility | "Can we take 500 hoodies by April 30?" |
| Operations brief | "What needs attention today?" |
| Claim trace | "Check claim CLM-... for me" |

- Click a claim badge in an answer to see its evidence. If a question is ambiguous (for example, it matches several orders), the AI shows choices for you to click.
- The left side shows your conversation history, where you can start or delete conversations.
- The AI **cannot** make changes (confirm actions, send messages, and so on) and cannot write SQL or code. For questions outside its tools, it explains what it can't answer.

## 4. Q&A

**Q1: The top-right corner says "API offline".**
The backend isn't running, or it is on another port. Check that the backend in window 1 is still running and that <http://127.0.0.1:8000/health> opens.

**Q2: The AI settings page shows "Not Found", or a new feature doesn't work.**
The backend is still running old code. Press `Ctrl+C` in the backend window and start it again with `--reload`, as in section 2.

**Q3: Starting the backend says `No module named uvicorn`.**
You are not using the Python in the project's virtual environment. On Windows use `.\.venv\Scripts\python.exe`; on macOS run `source .venv/bin/activate` first. If dependencies aren't installed yet, run the `pip install` command from section 2.

**Q4: Port 8000 or 5173 is already in use.**
An old process is still running. Close the old terminal windows first. If you can't find it, on Windows this command shows the process ID using the port, which you can then end in Task Manager:
```powershell
Get-NetTCPConnection -LocalPort 8000 -State Listen | Select-Object OwningProcess
```
On macOS, use `lsof -i :8000`.

**Q5: Chat says "AI is not configured".**
No API key has been saved. Go to *AI settings*, choose a provider and model, enter the key and save.

**Q6: Test connection says the key was rejected.**
The key is wrong, has expired, or doesn't match the provider you chose (for example, an OpenAI key used with Claude). Copy the key again, check the provider, and save.

**Q7: I get a rate limit or an HTTP 4xx/5xx error.**
- **429 (rate limit):** too many requests or no credit left. Wait and retry, or check your balance on the provider's platform.
- **400 / 404:** usually your account can't use that model. Try another model.
- **5xx:** the provider is having temporary problems. Try again later.

**Q8: The Save button is greyed out with a warning that encryption isn't configured.**
The backend has no encryption master key. When started with `backend.dev:app`, it creates and reads the key in `backend/.ai-credentials.key` automatically. If you start it another way, set the `AI_CREDENTIALS_ENCRYPTION_KEY` environment variable.

**Q9: I deleted or lost `backend/.ai-credentials.key`, and the saved key no longer works.**
Without the master key, the saved API key can't be decrypted. Click *Remove key*, then enter and save the key again. **Never** commit this key file to Git or send it to anyone.

**Q10: The AI's answer doesn't match the page data, or the AI refuses to answer.**
The AI answers only from tool results and says so when data is missing. Click the claim badges to check the evidence. For questions outside its tools (such as open-ended data analysis), the AI explains that it can't answer.

**Q11: How do I reset the demo records?**
Stop the backend, delete `backend/.frontend-demo.sqlite3`, and start the backend again; it creates a fresh database. This clears action records, chat conversations, AI settings and memories.

**Q12: How do I run the tests?**
```powershell
# Backend (project root)
.\.venv\Scripts\python.exe -m unittest discover -s backend -p "test_*.py" -t .
# Frontend (frontend folder)
npm test
```

**Q13: Can teammates open my app over the LAN?**
No; this isn't supported. The project has no login, and the AI settings and chat endpoints accept local requests only. For demos, each person should run the app on their own computer.
