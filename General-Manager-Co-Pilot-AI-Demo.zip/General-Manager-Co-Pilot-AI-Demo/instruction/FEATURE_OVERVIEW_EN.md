# The General Manager's Co-Pilot: Feature Overview

> This document describes every feature that is **built and usable today**, including the AI chat assistant. All examples are real results from running the system on the **course-provided data** (`data/`).
> For installation and startup, see [Team_Local_Setup_EN.md](Team_Local_Setup_EN.md). For step-by-step usage, see [USER_GUIDE_EN.md](USER_GUIDE_EN.md). For the Chinese version, see [FEATURE_OVERVIEW_CN.md](FEATURE_OVERVIEW_CN.md).

---

## 1. In one sentence

**An operations assistant for the general manager of a garment factory: ask about orders, output, risk or whether to accept an order in plain English, and get accurate numbers where every number can be opened to show where it came from.**

How it differs from simply asking ChatGPT:

| | Asking a general-purpose AI | Our Co-Pilot |
|---|---|---|
| Where numbers come from | The model "calculates" or guesses, and may invent them | Python code calculates them with fixed rules; results are reproducible |
| Can you check them? | No, you have to trust it | Every conclusion has **Evidence**; one click shows the source data and calculation steps |
| When a question is ambiguous | It may pick one and be wrong without telling you | It lists the candidates and lets you choose |
| Can it change data or send messages? | In principle, yes | The AI can only read; any write needs a human to confirm |

---

## 2. How it works at a glance

```text
 You (general manager)
    │  "Which orders need attention?"
    ▼
┌──────────────── Web app ─────────────────┐
│ Overview · Orders · Production ·         │
│ Feasibility · Action log · AI settings · │
│ AI chat                                  │
└───────────────────┬──────────────────────┘
                    ▼
          Backend API (localhost only)
                    │
    ┌───────────────┴───────────────┐
    ▼                               ▼
 AI assistant (agent)        Pages call it directly
 ① Understand the question          │
 ② Choose a tool ───────────────────┤
 ③ Explain the result               ▼
    ▲                     Deterministic business core (Python)
    │                     orders · output · risk · normality ·
    │                     feasibility · morning brief · claim trace
    │                               │ each conclusion is registered as a claim (evidence)
    └──── structured results ───────┤
                                    ▼
              Data: 3 CSV files (read-only) + SQLite (evidence, records, settings)
```

**Three things to remember:** **the AI interprets**, **the code calculates**, **people confirm**.

---

## 3. Feature map

| Feature | Where | What it does |
|---|---|---|
| Morning brief | Overview | One click produces "the top 5 things to look at today" |
| Stage output summary | Overview | Output and daily average for the four stages in the previous week (23–29 Mar) |
| Order search | Orders page / AI chat | Filter and summarise by order ID, customer, status and stage |
| Production report | Production page / AI chat | Daily output for any date range and stage |
| Order risk assessment | AI chat | Whether an order is at risk of missing its due date, and why |
| Output normality check | AI chat | Whether one stage's output on one day is abnormal compared with history |
| New order feasibility | Feasibility page / AI chat | "Can we take X pieces by this date?" with an estimate, bottleneck and outsourcing options |
| Evidence trace | Evidence button on every page | See the source data and calculation behind any conclusion, and re-verify it |
| Safe actions & audit | Action log page | Actions must be prepared, then confirmed; everything is logged |
| **AI chat assistant** | Overview question box / `/chat` | Ask in natural language; the AI calls the tools above to answer |
| AI settings | AI settings page | Choose a provider and model, save an encrypted API key, test the connection |
| Chat memory (optional) | AI settings page | Save your preferences (e.g. "keep answers short"); off by default |

---

## 4. Pages in detail

The left sidebar has six pages. **API connected** in the top-right corner means the backend is running. The top of each page shows **TRACK 1 · COURSE DATASET**, meaning the app is using the course-provided data.

### 4.1 Overview: the first page you open each day

From top to bottom, the page has four parts:

1. **Ask operations box:** the entry point to the AI chat. Type a question and press Enter, or click one of the three example questions, to open the full-screen chat and send it.
   - Example questions: *Which orders need attention?*, *How did assembly perform last week?*, *Can we take 500 hoodies by April 30?*
2. **Brief banner + Generate morning brief button:** runs all the risk and output rules and produces up to five findings in priority order.
3. **Morning brief:** shows the findings. Each one has a severity (CRITICAL / WARNING / INFO), a summary and a recommended next step.
4. **Stage throughput / Order pulse:** a bar chart of each stage's output and daily average for the week before the business date (23–29 Mar), plus the latest order records.

**Example** (business date 2026-04-01): the brief finds 7 issues, publishes the top 5 by priority, and puts 1 in the observation list

| Severity | Priority | Finding | Orders |
|---|---|---|---|
| CRITICAL | 90 | TrendCart has 2 high-risk orders | ORD-120, ORD-020 |
| CRITICAL | 90 | Bright Basics has 2 high-risk orders | ORD-103, ORD-062 |
| CRITICAL | 90 | Maple & Co has 2 high-risk orders | ORD-083, ORD-093 |
| CRITICAL | 90 | Cotton Club has 2 high-risk orders | ORD-002, ORD-055 |
| CRITICAL | 90 | Northwind Apparel has 4 high-risk orders | ORD-107, ORD-114, ORD-099, ORD-029 |
| Observation | — | Assembly output on 31 Mar was 455 pieces, below the same-weekday median | — |

Each finding comes with a recommended next step, such as "Review the affected orders together with the account owner".

> Brief priority is weighted 40% urgency, 30% impact, 20% anomaly and 10% spread. These weights are team assumptions and can be changed in `rules_config.json`.

### 4.2 Orders

- **Purpose:** find and compare current orders.
- **How:** fill in any of **Order ID / Customer / Status / Stage** (all conditions must match), then click **Search**.
- **Result:** the number of matching orders, their total pieces, and a paginated order list. There is an Evidence button at the top right.

**Examples**

| Filters | Result |
|---|---|
| None | 120 orders, 93,500 pieces (sorted by due date, 20 per page) |
| Status = In progress | 34 orders, 32,850 pieces |
| Customer = TrendCart | 17 orders, 15,050 pieces |
| Customer = TrendCart + Status = In progress | 6 orders, 5,600 pieces: ORD-120, ORD-020, ORD-017, ORD-096, ORD-005, ORD-082 |
| Order ID = ORD-999 | No match (it never returns the "closest" order instead) |

### 4.3 Production

- **Purpose:** see how much each stage produced each day over a period.
- **How:** choose a **Start date** and **End date** (both included) and an optional **Stage**, then click **Run report**.
- **Result:** daily output per stage; totals and working-day averages per stage; and data coverage (whether the data is complete).

**Example:** last week (23–29 Mar) has complete coverage, with 6 working days

| Stage | Total | Working-day average |
|---|---|---|
| KNITTING | 5,744 | 957.3 |
| ASSEMBLY | 3,214 | 535.7 |
| WASHING | 4,517 | 752.8 |
| PACKING | 3,983 | 663.8 |

Asking for 1 April returns **NO_DATA**, because the production log ends on 31 March.

**Rules to know:**
- Each stage's figure is a **separate process count**. One garment passing through four stages is counted four times, so **don't add stages together** to get finished pieces.
- Sunday is a closed day and is left out of averages.
- A missing record stays missing; it is **never treated as 0**. When data is incomplete, the system flags it and does not give an average.

### 4.4 Feasibility

- **Purpose:** when a customer asks "Can you deliver X pieces by this date?", give an estimate with a basis.
- **How:** enter the product, category (TOPS / ACCESSORIES), quantity and requested due date; choose whether to evaluate outsourcing; then click **Estimate feasibility**.
- **Result:**
  - **Classification** (e.g. LIKELY_FEASIBLE) and confidence
  - **Estimated completion range** and available working days
  - **Bottleneck stage**
  - **Outside workshop options:** each workshop's estimated completion date, slack, quoted cost and defect rate; ineligible workshops are listed with the reason
  - **Assumptions** and **limitations**

**Example:** 500 hoodies (TOPS), due by 30 April

| Item | Result |
|---|---|
| Classification | **FEASIBLE_WITH_OUTSOURCING**, LOW confidence |
| Available working days | 25 |
| Internal capacity only | Not feasible: done around 2026-06-10 to 2026-09-30, bottleneck PACKING |
| Workshop options (5) | W1: done around 9 Apr, quoted 750, 12% defect rate<br>W2: done around 10 Apr, quoted 650, 3% defect rate<br>W3: done around 14 Apr, quoted 400, 9% defect rate<br>(plus W5 and W6; quotes have no currency in the data) |
| Excluded workshops (3) | W4: doesn't make tops · W7: suspended · W8: batch limit exceeded |

> This is an **estimate**, not a production schedule or a delivery promise. Method: capacity is the median output of the last 20 working days, with a 15% safety buffer. Every remaining stage of each of the 34 orders in progress is loaded with the order's full piece count. That assumption is conservative, so the internal completion date comes out late.

### 4.5 Action log

- **Purpose:** see the history of all actions: prepared, confirmed and cancelled.
- There are four action types: add an order note, create a reminder, create a watch, and draft a chase-up message.
- **Safety rules:**
  - Every action is first **prepared** (PREPARE), which produces a preview and a one-time token. The user must then explicitly **confirm** (CONFIRM) or **cancel** (CANCEL).
  - Each token works only once; a repeated confirmation is refused.
  - Actions are **only recorded locally**. Nothing is actually sent or scheduled, and chase-up messages are drafts only.
- **Current limit:** this page only shows the records. Preparing and confirming actions is done through the API (`http://127.0.0.1:8000/docs`) or the command line. Starting actions from the chat is planned for the next phase.

### 4.6 Evidence (claim trace): available everywhere

Click any **Evidence ↗** button and the **Claim trace** panel slides in from the right. It shows:

| Section | Contents |
|---|---|
| **Conclusion** | The statement itself, e.g. "2 high-risk orders are associated with TrendCart.", and its ID `CLM-20260401-DISC-001-…` |
| **Provenance** | Which tool produced it, rule version, business date, generation time |
| **Source snapshots** | Which data files were used and their version fingerprints (SHA-256) at the time; how many source rows were stored |
| **Calculation steps** | The calculation step by step, with each step's formula and intermediate result |

Click **Re-verify claim** at the bottom to recalculate it from the **current data**:

- **CONSISTENT:** the result matches the original
- **DRIFTED:** the data has changed and so has the result
- **SOURCE_UNAVAILABLE:** the original data snapshot can't be found

> This is what stops the AI from inventing numbers: every business number has an evidence record that can be checked and recalculated.

### 4.7 AI settings

**AI connection: connecting a model**

1. **AI provider:** choose a provider from the drop-down. The backend sets each provider's API address, so there is nothing to type, and it can't be pointed at a malicious address.
2. **Model:** choose one of that provider's models. Changing the provider automatically selects its first model.
3. **API key:** paste your key and click **Save settings**, then click **Test connection**.

| Provider | Models |
|---|---|
| ChatGPT (OpenAI) | GPT-4.1 mini (default) · GPT-4.1 · GPT-6 Luna |
| Claude (Anthropic) | Claude Sonnet 5.5 · Claude Opus 5.5 · Claude Haiku 4.5 |
| Gemini (Google) | Gemini 3.8 Flash · Gemini 3.5 Flash-Lite · Gemini 3.1 Pro (Preview) |
| DeepSeek | DeepSeek V4.1 Flash · DeepSeek V4 Pro |

**API key safety:**
- The key is **AES-GCM encrypted** before it is stored in the local database. The encryption master key is a separate file, created automatically on first start.
- Once saved, the page **never shows the key again**; it only shows *CONFIGURED*. The browser never receives the key, and the backend makes all model calls.
- To change only the model, leave the key box empty and the saved key is kept. Click *Remove key* to delete it.

**Chat memory (optional, off by default)**
- When it is on, you can add preferences by hand (up to 500 characters each), such as "Prefer concise summaries".
- The 20 most recent preferences are given to the AI as context with each question. Preferences are **never** used as a source of business facts.
- You can view them, delete one at a time, or clear them all at any time. The AI **never** writes to memory on its own.

---

## 5. The AI chat assistant (the main feature)

### 5.1 Getting there

- **Option 1:** type a question in the **Ask operations** box on the Overview page and press Enter, or click an example question. The chat opens and sends it automatically.
- **Option 2:** go straight to <http://127.0.0.1:5173/chat>.

### 5.2 What the chat page looks like

```text
┌──────────────┬──────────────────────────────────────────────┐
│ ← Workspace  │ 🤖 Operations assistant   AI settings  Exit ✕│
│ [+ New chat] ├──────────────────────────────────────────────┤
│              │  You: Which orders need attention?          │
│ RECENT       │                                              │
│ CONVERSATIONS│  🤖 Operations assistant                     │
│ · Chat 1  🗑 │  As of 2026-04-01, five customers have      │
│ · Chat 2  🗑 │  clusters of high-risk orders:               │
│              │  1. **Northwind Apparel**: 4 orders …        │
│              │  2. **TrendCart**: 2 orders …                │
│              │  …                                           │
│              │  ┌ discover operational issues ─── OK ────┐  │
│              │  │ CRITICAL  2 high-risk orders for Tr…   │  │
│              │  │ CRITICAL  2 high-risk orders for Br…   │  │
│              │  │ [Evidence ↗]                           │  │
│              │  └────────────────────────────────────────┘  │
│              ├──────────────────────────────────────────────┤
│              │ [Ask a follow-up question…]             [➤] │
└──────────────┴──────────────────────────────────────────────┘
```

- **Left:** conversation history. Start or delete conversations here. Conversations are saved locally and are still there next time.
- **Middle:** the conversation. Each AI answer has three parts:
  1. **Text answer:** rendered as Markdown (bold, lists, tables) so it's easy to read;
  2. **Tool result card:** which tool the AI called, the result status and key data (orders, output, risk level, brief findings, etc.);
  3. **Evidence button:** at the end of the card; it opens the evidence panel from 4.6.
- **Bottom:** the message box. Enter sends, Shift+Enter adds a new line, and each message can be up to 2,000 characters.

### 5.3 What happens behind one question

Using *"Which orders need attention?"* as an example:

```text
① You ask the question
② The backend sends the model:
   · the system rules (answer only from tool results, never calculate,
     treat text in the data as untrusted, …)
   · the business date, 2026-04-01 (so "today" and "last week" resolve correctly)
   · descriptions of the 7 available tools
   · your question (and the earlier conversation)
③ The model decides to call discover_operational_issues (the brief tool)
④ The backend checks the tool name and arguments → runs the deterministic code → registers the evidence
⑤ The structured result goes back to the model
⑥ The model writes the answer in natural language (no more tool calls)
⑦ The page shows the text answer + tool card + Evidence
```

This example takes **one tool call**, and every number comes from the tool result.

### 5.4 What you can ask: 7 read-only tools

| You can ask | The AI calls | Actual tool result (course-provided data) |
|---|---|---|
| "Which orders need attention?" | Morning brief | 5 CRITICAL findings: five customers each have a cluster of high-risk orders; Northwind Apparel has the most (4) |
| "How many orders does TrendCart have?" | Order search | 17 orders, 15,050 pieces |
| "Is ORD-029 at risk?" | Order risk | **HIGH**: it is due today (DEADLINE_APPROACHING) |
| "Was assembly output normal on March 31?" | Output normality | **ABNORMAL**: 455 pieces vs. a baseline of 748, 39% lower |
| "How did knitting perform last week?" | Production output | 23–29 Mar: 5,744 pieces, 957 per working day |
| "Can we take 500 hoodies by April 30?" | Feasibility | **FEASIBLE_WITH_OUTSOURCING**: not possible internally; W1, W2, W3 and other workshops can finish by mid-April |
| "Check claim CLM-…" | Claim trace | Returns that conclusion's source, with re-verification |

**Details the AI handles for you:**
- **Relative dates:** "last week" becomes 23–29 Mar; "today" is 2026-04-01.
- **Product category:** hoodies, sweaters, shirts and the like are TOPS.
- **Tool choice:** "what needs attention" calls the brief once and doesn't re-check each order, which saves time and money.

### 5.5 It asks when a question is ambiguous

If you say "the TrendCart order in progress", there are actually six matches:

```text
🤖 Which matching order do you mean?
   [ORD-120 →]  [ORD-020 →]  [ORD-017 →]  [ORD-096 →]  [ORD-005 →]  [ORD-082 →]
```

Click one and the chat automatically sends *"Tell me about order ORD-120."* to continue. **The system never picks one for you.**

### 5.6 What the AI won't do

| It won't | Why |
|---|---|
| Calculate numbers itself | Every number must come from a tool |
| Write SQL or code, or read arbitrary files | It can only call the 7 allowlisted tools, with strictly validated arguments |
| Change data, confirm actions or send messages | The AI is read-only; writes need human confirmation |
| Answer things the data doesn't contain | Such as order-level daily output, revenue and profit, or worker performance; it says the data doesn't support it |
| Treat text in the data as instructions | Customer names, notes and similar text are treated as untrusted data, which guards against prompt injection |

### 5.7 Reliability and cost control

- **Call budget:** each question gets at most 3 rounds of tool calls and 5 calls in total. When the budget is used up, the AI is told to answer from the results it already has, so nothing collected is thrown away.
- **Switchable providers:** you can switch between 4 providers at any time. If one has an outage, switch and carry on.
- **Clear errors:** a wrong key, no credit (429) or a provider timeout each produce a cleaned-up message. Raw provider errors and keys are never shown on the page.

---

## 6. Security and privacy summary

| Area | Approach |
|---|---|
| Access | Services listen on this computer only (127.0.0.1); AI settings and chat endpoints refuse non-local requests |
| API keys | AES-GCM encrypted; master key stored separately; never shown on the page or sent to the browser |
| Data | The source CSV files are read-only; no feature changes them |
| Writes | Prepare → human confirmation → execute; single-use tokens; everything is audit-logged |
| AI permissions | Only 7 read-only tools are available; calls to unregistered tools are refused (covered by tests) |
| Answer display | Answers are rendered as Markdown, but any HTML in them is not executed |
| Memory | Off by default; added by hand only; viewable and deletable; never used as a source of facts |

---

## 7. About the data

The project uses the course-provided data in the `data/` folder. The web app, AI chat and every feature run on it, and it has been **validated end to end**.

| File | Contents |
|---|---|
| `orders.csv` | 120 orders (34 in progress), 93,500 pieces in total |
| `production_log.csv` | 360 rows: daily output for 4 stages over 90 days (1 Jan – 31 Mar) |
| `workshops.csv` | 8 outside workshops (1 suspended) |
| `data_dictionary.md` | Field descriptions |

The business "today" is fixed at **2026-04-01**, not the computer's current date. Otherwise every order would be flagged as overdue.

---

## 8. Quality checks

- **Validation on the course-provided data (done, 46/46 checks passed):**
  - the SHA-256 fingerprints of all 3 data files match the ones recorded in the A specification;
  - all 32 acceptance questions (A01–A32) in the A specification match the manually verified answers, and the 90-day stage totals match exactly;
  - end to end: the morning brief, order risk, output normality, new order feasibility, evidence trace and re-verification (CONSISTENT), and actions (prepare → confirm → repeated confirmation refused) all work.
- **Automated tests:** 40 backend and 7 frontend tests, all passing. They cover ambiguous orders, missing output, Sunday closures, risk rules, feasibility scenarios, brief ranking, claim re-verification, action tokens, the tool allowlist, the call budget, key encryption, localhost-only access, safe Markdown rendering and more.
- **Live model test:** with Claude Sonnet 5.5, "Which orders need attention?" was answered correctly with a single call to the brief tool, listing the five customers' high-risk order clusters; every number came from the tool.
- **Clean install:** the packaged project was installed from scratch on a fresh environment following the setup guide; dependency installation, tests and startup all succeeded.

---

## 9. Not built yet (next phase)

To avoid any confusion, the following are **not finished yet**:

- An **evaluation set of 30+ questions** and failure-case analysis (to measure accuracy)
- **Starting actions from the chat** (the AI prepares an action and the user confirms it in the chat)
- **Scheduled** morning briefs and automatic reminders for watched orders (the brief is currently generated by clicking a button)
- Login and multi-user shared deployment (currently single user on one computer)
