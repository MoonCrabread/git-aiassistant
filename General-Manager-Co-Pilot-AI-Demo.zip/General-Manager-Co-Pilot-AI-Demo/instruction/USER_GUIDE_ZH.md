# Fieldwork Operations Co-Pilot 使用指南

本指南说明如何在本机启动后端和网页、各页面能做什么，以及常见问题的处理方法。英文版见 [USER_GUIDE_EN.md](USER_GUIDE_EN.md)。

> 网页和 AI 使用 `data/` 下的**课程提供数据**（120 个订单），业务日期固定为 2026-04-01。所有服务只监听本机地址 `127.0.0.1`，没有登录认证，请勿开放到局域网或公网。

## 1. 环境准备

| 软件 | 版本 | 检查命令 |
|---|---|---|
| Python | 3.11 及以上 | `py -3.11 --version`（Windows）/ `python3 --version`（macOS） |
| Node.js | 20 及以上 | `node --version` |

首次启动需要联网安装依赖，之后可直接启动。以下命令都从**项目根目录**（包含 `backend/`、`frontend/` 的文件夹）开始执行。

## 2. 启动后端和网页

需要同时开**两个终端窗口**：一个运行后端（端口 8000），一个运行网页（端口 5173）。两个窗口都要保持运行。

### Windows（PowerShell）

**窗口 1：后端**

```powershell
cd <项目目录>
# 仅首次：创建虚拟环境并安装依赖
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r backend\requirements.txt

# 每次启动
.\.venv\Scripts\python.exe -m uvicorn backend.dev:app --host 127.0.0.1 --port 8000 --reload --reload-dir backend
```

**窗口 2：网页**

```powershell
cd <项目目录>\frontend
# 仅首次：安装依赖
npm ci

# 每次启动
npm run dev
```

### macOS（Terminal）

**窗口 1：后端**

```bash
cd <项目目录>
# 仅首次
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r backend/requirements.txt

# 每次启动（新窗口需先 source .venv/bin/activate）
python -m uvicorn backend.dev:app --host 127.0.0.1 --port 8000 --reload --reload-dir backend
```

**窗口 2：网页**

```bash
cd <项目目录>/frontend
npm ci        # 仅首次
npm run dev
```

### 打开网页

| 地址 | 用途 |
|---|---|
| <http://127.0.0.1:5173> | 网页主界面 |
| <http://127.0.0.1:8000/health> | 后端健康检查 |
| <http://127.0.0.1:8000/docs> | 后端 API 文档（可直接在页面上试调用） |

右上角显示 **API connected** 即表示前后端已连通。停止服务时，在两个终端分别按 `Ctrl+C`。

> **关于 `--reload`**：加上后，修改 `backend/` 下的代码会自动重启后端。开发时建议总是加上；不加的话，改完代码必须手动重启，否则网页仍在调用旧代码（常见症状是新接口返回 `Not Found`）。

## 3. 功能说明

左侧导航栏共 6 个页面，另有全屏聊天页。

### 3.1 Overview（运营总览）

- **Ask operations 输入框**：输入运营问题后按回车，或点击下方示例问题，进入 AI 聊天页（需先完成 AI 配置，见 3.7）。
- **Generate morning brief**：运行确定性规则，生成优先级最高的若干条运营发现（Morning brief）。
- **Stage throughput**：本周各生产阶段（KNITTING / ASSEMBLY / WASHING / PACKING）的产量和日均产量。
- **Order pulse**：最近的订单记录，可点 *Open order book* 进入订单页。

### 3.2 Orders（订单簿）

- 按 **Order ID、Customer、Status、Stage** 组合筛选（条件之间是"且"的关系），点击 *Search*。
- 显示匹配订单数和总件数，支持分页。

### 3.3 Production（生产脉搏）

- 选择 **Start date / End date**（含首尾日期）和可选的 **Stage**，点击 *Run report*。
- 显示全厂各阶段的日产量。各阶段数量是**独立的工序计数**，不能相加成成品件数。
- 缺失的记录不会被当作 0；周日为非生产日。

### 3.4 Feasibility（新订单可行性）

- 输入 **Product、Category（TOPS / ACCESSORIES）、Quantity、Requested due date**，可选是否评估外发（*Evaluate outsourcing*）。
- 点击 *Estimate feasibility*，根据近期产能和现有订单负载估算可能的生产窗口。
- 结果是**估算**，不是排程或交期承诺。

### 3.5 Action log（动作记录）

- 查看本机 SQLite 中记录的动作：已准备（PREPARED）、已确认、已取消。
- 动作只写入本地记录，**不会**真正发送消息、创建提醒或启动监控。

### 3.6 Claim 证据追溯

页面和聊天中出现的 claim 标签（形如 `CLM-...`）都可以点击，打开右侧 **Claim trace** 面板：

- 查看该结论的来源数据和计算依据。
- 点击 *Re-verify claim* 用当前数据重新计算，结果为 `CONSISTENT`（一致）、`DRIFTED`（数据已变化）或 `SOURCE_UNAVAILABLE`（源数据不可用）。

### 3.7 AI settings（AI 设置）

**AI connection：配置模型**

1. **AI provider**：选择厂家，可选 ChatGPT（OpenAI）、Claude（Anthropic）、Gemini（Google）或 DeepSeek。各厂家的接口地址由后端固定，无需填写。
2. **Model**：从该厂家的预设模型中选择。切换厂家时会自动选中第一个模型。
3. **API key**：粘贴你在对应厂家平台申请的 API key。
4. 点击 **Save settings** 保存，再点 **Test connection** 测试连接。

| 厂家 | 预设模型 | API key 申请地址 |
|---|---|---|
| ChatGPT | GPT-4.1 mini（默认）、GPT-4.1、GPT-6 Luna | platform.openai.com |
| Claude | Claude Sonnet 5.5、Claude Opus 5.5、Claude Haiku 4.5 | console.anthropic.com |
| Gemini | Gemini 3.8 Flash、Gemini 3.5 Flash-Lite、Gemini 3.1 Pro (Preview) | aistudio.google.com |
| DeepSeek | DeepSeek V4.1 Flash、DeepSeek V4 Pro | platform.deepseek.com |

关于 API key 的安全：
- 保存后 API key 由后端**加密**存入本机 SQLite，页面永远不会再显示它，只显示 *CONFIGURED* 状态。
- 要更换 key，直接输入新 key 再保存；只改厂家或模型时，key 输入框留空即可，已保存的 key 会保留。
- 点击 *Remove key* 删除已保存的 key。
- 测试连接和聊天会调用厂家的 API，可能**产生费用**。

**Chat memory：聊天记忆（可选，默认关闭）**

- 打开开关后，可以手动添加偏好（例如"回答尽量简洁"），后续对话会把它们作为上下文。
- 记忆只是偏好，**不是**业务事实来源；订单、产量等仍由工具实时查询。
- 可以单条删除，或点 *Clear all memories* 全部清空。

### 3.8 AI 聊天页（/chat）

- 从总览页输入框进入，或直接访问 <http://127.0.0.1:5173/chat>。
- AI 只能调用以下**只读**工具，所有数字都由后端确定性计算，AI 不会自行计算：

| 工具 | 能回答的问题示例 |
|---|---|
| 订单查询 | "TrendCart 有哪些进行中的订单？" |
| 生产产量 | "上周组装（assembly）产量怎么样？" |
| 订单风险 | "ORD-058 有交期风险吗？" |
| 产量是否正常 | "4 月 1 日针织产量正常吗？" |
| 新订单可行性 | "4 月 30 日前能接 500 件卫衣吗？" |
| 运营晨报 | "今天需要关注什么？" |
| Claim 追溯 | "帮我核对 CLM-... 这条结论" |

- 回答里的 claim 标签可以点击查看证据。问题有歧义时（例如匹配到多个订单），AI 会给出候选项让你点选。
- 左侧是会话历史，可以新建或删除会话。
- AI **不能**执行写操作（确认动作、发消息等），也不能写 SQL 或代码；超出范围的问题会被说明边界。

## 4. 常见问题（Q&A）

**Q1：右上角显示 "API offline"。**
后端没在运行，或运行在其他端口。确认窗口 1 的后端仍在运行，并能打开 <http://127.0.0.1:8000/health>。

**Q2：AI settings 页面显示 "Not Found"，或其他新功能不生效。**
后端还在跑旧代码。在后端窗口按 `Ctrl+C` 后重新启动，并按第 2 节加上 `--reload`。

**Q3：启动后端提示 `No module named uvicorn`。**
用的不是项目虚拟环境里的 Python。Windows 用 `.\.venv\Scripts\python.exe`，macOS 先运行 `source .venv/bin/activate`。如果虚拟环境还没装依赖，执行第 2 节的 `pip install` 命令。

**Q4：提示端口 8000 或 5173 已被占用。**
有旧的进程还在运行。先关掉之前的终端窗口；找不到的话，Windows 可以执行下面的命令查看占用端口的进程 ID，再到任务管理器结束它：
```powershell
Get-NetTCPConnection -LocalPort 8000 -State Listen | Select-Object OwningProcess
```
macOS 可以用 `lsof -i :8000`。

**Q5：聊天时提示 "AI is not configured"。**
还没保存 API key。到 *AI settings* 选择厂家和模型、填入 key 并保存。

**Q6：Test connection 提示 key 被拒绝（rejected）。**
key 填错、已失效，或者和所选厂家不匹配（例如把 OpenAI 的 key 用在 Claude 上）。重新复制 key，确认厂家选对后再保存。

**Q7：提示 rate limit 或 HTTP 4xx/5xx 错误。**
- **429（rate limit）**：请求太频繁或额度用完，稍后再试，或到厂家平台检查余额。
- **400 / 404**：通常是账号没有该模型的权限，换一个模型试试。
- **5xx**：厂家服务暂时故障，稍后再试。

**Q8：保存按钮是灰色的，并提示加密未配置。**
后端没有拿到加密主密钥。用 `backend.dev:app` 启动时，会自动在 `backend/.ai-credentials.key` 生成并读取密钥；如果用其他方式启动，需要设置环境变量 `AI_CREDENTIALS_ENCRYPTION_KEY`。

**Q9：删除或丢失了 `backend/.ai-credentials.key`，之前保存的 key 无法使用。**
加密主密钥丢失后，已保存的 API key 无法解密。点击 *Remove key*，再重新输入 key 保存即可。**不要**把这个密钥文件提交到 Git 或发给别人。

**Q10：AI 的回答和页面数据对不上，或者 AI 拒绝回答。**
AI 只根据工具返回的结果回答，数据不足时会明确说明。点 claim 标签核对证据；问题超出工具范围（例如任意数据分析）时，AI 会说明无法回答。

**Q11：怎么清空所有记录，重新开始？**
停止后端后删除 `backend/.frontend-demo.sqlite3`，重启后端会重新创建。这会清空动作记录、聊天会话、AI 设置和记忆。

**Q12：怎么运行测试？**
```powershell
# 后端（项目根目录）
.\.venv\Scripts\python.exe -m unittest discover -s backend -p "test_*.py" -t .
# 前端（frontend 目录）
npm test
```

**Q13：同事能通过局域网访问我的页面吗？**
不建议，也不支持。项目没有登录认证，AI 设置和聊天接口只允许本机访问。需要演示时，请每人在自己电脑上运行。
